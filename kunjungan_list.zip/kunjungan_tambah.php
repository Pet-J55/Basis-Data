<?php
include 'koneksi.php';

// Ambil ID pasien dari URL
$id_pasien = $_GET['id'] ?? null;

// Ambil data pasien spesifik
$pasien_terpilih = null;
if ($id_pasien) {
    $stmt = $conn->prepare("SELECT * FROM pasien WHERE no_pasien = ?");
    $stmt->execute([$id_pasien]);
    $pasien_terpilih = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Ambil data dokter & poli
$dokter = $conn->query("SELECT * FROM dokter");
$poli = $conn->query("SELECT * FROM poli");

// Proses simpan kunjungan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id_pasien = $_POST['no_pasien'];
    $id_dokter = $_POST['no_dokter'];
    $id_poli   = $_POST['id_poli'];
    $tgl       = $_POST['tanggal'];
    $keluhan   = $_POST['keluhan'];

    $sql = "INSERT INTO kunjungan(no_pasien, no_dokter, id_poli, keluhan, tgl_periksa, status)
            VALUES (?, ?, ?, ?, ?, 'Menunggu')";

    $stmt = $conn->prepare($sql);
    if ($stmt->execute([$id_pasien, $id_dokter, $id_poli, $keluhan, $tgl])) {
        header("Location: kunjungan_list.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Buat Kunjungan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div id="wrapper" class="d-flex">

    <div class="bg-dark border-right" id="sidebar-wrapper">
        <div class="sidebar-heading text-white p-3 fs-4">Resepsionis</div>

        <div class="list-group list-group-flush">
            <a href="dashboard_resepsionis.php" class="list-group-item list-group-item-action bg-dark text-white">
                <i class="fa fa-users"></i> Dashboard
            </a>
            <a href="pasien_list.php" class="list-group-item list-group-item-action bg-dark text-white">
                <i class="fa fa-users"></i> Data Pasien
            </a>
        

            <a href="pasien_tambah.php" class="list-group-item list-group-item-action bg-dark text-white">
                <i class="fa fa-user-plus"></i> Tambah Pasien
            </a>

            <a href="kunjungan_tambah.php" class="list-group-item list-group-item-action bg-dark text-white">
                <i class="fa fa-calendar-plus"></i> Jadwal Kunjungan
            </a>

            <a href="kunjungan_list.php" class="list-group-item list-group-item-action bg-dark text-white">
                <i class="fa fa-calendar"></i> Data Kunjungan
            </a>

            <a href="../login.php?logout=true" class="list-group-item list-group-item-action bg-dark text-white">
                <i class="fa fa-right-from-bracket"></i> Logout
            </a>
        </div>
    </div>

<div class="container mt-4">

    <h3>Buat Jadwal Kunjungan</h3>

    <form method="POST" class="row g-3">

        <!-- PASIEN -->
        <div class="col-md-6">
            <label>Pasien</label>

            <?php if ($pasien_terpilih): ?>
                <!-- Tampilkan nama pasien yang diklik -->
                <input type="text" class="form-control" value="<?= $pasien_terpilih['nama_pasien'] ?>" readonly>
                <input type="hidden" name="no_pasien" value="<?= $pasien_terpilih['no_pasien'] ?>">
            
            <?php else: ?>
                <!-- Jika tidak lewat tombol "Buat Kunjungan", tampilkan dropdown -->
                <select name="no_pasien" class="form-control" required>
                    <option value="">-- Pilih Pasien --</option>
                    <?php
                    $ps = $conn->query("SELECT * FROM pasien");
                    while($p = $ps->fetch(PDO::FETCH_ASSOC)):
                    ?>
                        <option value="<?= $p['no_pasien'] ?>"><?= $p['nama_pasien'] ?></option>
                    <?php endwhile; ?>
                </select>
            <?php endif; ?>
        </div>

        <!-- DOKTER -->
        <div class="col-md-6">
            <label>Dokter</label>
            <select name="no_dokter" class="form-control" required>
                <option value="">-- Pilih Dokter --</option>
                <?php while($d = $dokter->fetch(PDO::FETCH_ASSOC)): ?>
                    <option value="<?= $d['no_dokter'] ?>"><?= $d['nama_dokter'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- POLI -->
        <div class="col-md-6">
            <label>Poli</label>
          <select name="id_poli" class="form-control" required>
    <option value="">-- Pilih Poli --</option>
    <?php while($po = $poli->fetch(PDO::FETCH_ASSOC)): ?>
        <option value="<?= $po['id_poli'] ?>"><?= $po['nama_poli'] ?></option>
    <?php endwhile; ?>
</select>

        </div>

        <!-- TANGGAL -->
        <div class="col-md-6">
            <label>Tanggal Kunjungan</label>
            <input type="date" name="tanggal" class="form-control" required>
        </div>

        <!-- KELUHAN -->
        <div class="col-md-12">
            <label>Keluhan</label>
            <textarea name="keluhan" class="form-control"></textarea>
        </div>

        <div class="col-md-3">
            <button class="btn btn-success w-100 mt-3">Simpan</button>
        </div>

    </form>

</div>

</body>
</html>
